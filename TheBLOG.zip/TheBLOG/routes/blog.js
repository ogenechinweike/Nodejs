var express = require('express');
var router = express.Router();
let blog = [];
let id = 1;


/* POST users listing. */
router.post('/create', function(req, res, next) {
  console.log(req.body);
  let body = req.body;
     body.id = id
     id += 1;
     blog.push(body)
     console.log(blog)
  res.send('article  succesfully posted');
});
/* GET users listing. */
router.get('/read', function(req, res, next) {
  res.send('respond with a resource');
});
/* PUT users listing. */
router.put('/update', function(req, res, next) {
  res.send('updating...');
});
/* DELETE users listing. */
router.delete('/delete', function(req, res, next) {
  res.send('deleting at the moment');
});
router.get('/all', function(req, res, next) {
  res.send(blog);
});
module.exports = router;
